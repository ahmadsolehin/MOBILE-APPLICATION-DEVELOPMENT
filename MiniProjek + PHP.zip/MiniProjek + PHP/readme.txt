create database
dbname itemdb
tablename itemtb
5 col- 
int id, primary, autoincrement
varchar name, description, date, time
ubah url localhost ikut webserver 