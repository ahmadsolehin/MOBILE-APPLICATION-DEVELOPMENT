package com.example.sony.miniprojek;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;

/**
 * Created by Hazim on 07-Dec-16.
 */

public class Sender extends AsyncTask<Void,Void,String> {

    String urlAddress;
    String nameTxt, dateTxt, timeTxt, descTxt, idTxt;

    Item item;

    ProgressDialog pd;

    public Sender(String urlAddress, String nameTxt, String descTxt, String dateTxt, String timeTxt) {
        this.urlAddress = urlAddress;
        this.nameTxt = nameTxt;
        this.dateTxt = dateTxt;
        this.timeTxt = timeTxt;
        this.descTxt = descTxt;

        item = new Item();
        item.setName(nameTxt);
        item.setDate(dateTxt);
        item.setDescription(descTxt);
        item.setTime(timeTxt);
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(Void... params) {
        return this.send();
    }


    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

    }

    private String send() {
        HttpURLConnection con = MySQLConnector.connect(urlAddress);
        if (con == null) {
            return null;
        }

        try {

            OutputStream os = con.getOutputStream();

            //WRITE
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
            bw.write(new DataPackager(item).packData());

            bw.flush();
            //RELEASE
            bw.close();
            os.close();

            //SUCCESS OR NOT??
            int responseCode = con.getResponseCode();
            if (responseCode == con.HTTP_OK) {
                BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuffer response = new StringBuffer();

                String line;
                while ((line = br.readLine()) != null) {
                    response.append(line);
                }

                br.close();
                return response.toString();
            } else {
                return "Bad Response";
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


        return null;
    }
}