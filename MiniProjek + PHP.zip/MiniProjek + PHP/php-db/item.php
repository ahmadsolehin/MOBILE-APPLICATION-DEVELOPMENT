<?php


$host='127.0.0.1';
$username='root';
$pwd='';
$db="itemdb";

$con=mysqli_connect($host,$username,$pwd,$db) or die('Unable to connect');

if(mysqli_connect_error($con))
{
	echo "Failed to Connect to Database ".mysqli_connect_error();
}

$name=$_POST['name'];
$time=$_POST['time'];
$date=$_POST['date'];
$description=$_POST['description'];

$sql="INSERT INTO itemtb(name, description, dte, tme) VALUES('$name','$description', '$date', '$time')";

$result=mysqli_query($con,$sql);

if($result)
{
	echo ('Successfully Saved........');

}else
{
	echo('Not saved Successfully............');

}

mysqli_close($con);

?>
